#define NO_SYS                          1

/* they'd require NO_SYS=0, but are enabled by default */
#define LWIP_SOCKET                     0
#define LWIP_NETCONN                    0

#define LWIP_IPV6                       1
#define LWIP_IPV6_REASS                 0


#define MEMP_USE_CUSTOM_POOLS 1

#include "hci/hci_audio.h"

void set_audio_state(uint16_t handle, sco_codec_t codec, sco_state_t state)
{
    //todo
    return;
}
